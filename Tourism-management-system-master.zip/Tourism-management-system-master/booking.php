<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE HTML>
<html>
<head>
<title>TMS |Boking</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/main.css" rel="stylesheet">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/main.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css" />
	<script>
		 new WOW().init();
	</script>
	</head>
	
	<!-- HEAD TAG ENDS -->
	
	<!-- BODY TAG STARTS -->
	
	<body>
    <!-- top-header -->
           <?php include('includes/header.php');?>
           <div class="slider-3">
	        <div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> TMS -Booking</h1>
	</div>
</div>
  <!--- /slider ---->
		
		<?php include("common/headerLoggedIn.php"); ?>
		
		<?php
		
			$mode=$_POST["modeHidden"];
		
		?>
		
		<?php
		
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "tms1";
			
			// Creating a connection to tms1 MySQL database
			$conn = new mysqli($servername, $username, $password, $dbname);
			
			// Checking if we've successfully connected to the database
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
		
		?>
		
		<div class="spacer">a</div>
		
		<div class="bookingWrapper">
			
			<div class="headingOne">
				
				Please review and confirm your booking
				
			</div>
			
			<!-- changing contents of the page based on mode -->
			
			
		
			<?php elseif($mode=="bus"): ?>
			
			<div class="col-sm-12 bookingBus">
			
			<?php
				
				$busID = $_POST["busIDPass"];
				$date=$_POST["dateHidden"];
				$origin=$_POST["originHidden"];
				$destination=$_POST["destinationHidden"];
				$depart=$_POST["departHidden"];
				$return=$_POST["returnHidden"];
				$noOfPassengers= $_POST["passengersHidden"];
				
				$busFinderSQL = "SELECT * FROM `bus` WHERE busID='$busID'";
				$busFinderQuery = $conn->query($busFinderSQL);
				$row = $busFinderQuery->fetch_assoc();
				//$outboundFlightFare = $outboundFlightQuery->fetch_array(MYSQLI_NUM);
				
			?>
				
				<div class="col-sm-7"> <!-- departure container -->
				
				<div class="col-sm-12">
				
					<div class="boxLeftBus">
					
						<div class="col-sm-12 mode">Departure</div>
						
						<div class="col-sm-4">
						
						<div class="origin"><?php echo $origin; ?></div>
						<div class="departs">Departs <?php echo $row["originArea"]; ?> at: <?php echo $row["departure"]; ?></div>
						
						</div>
						
						<div class="col-sm-4">
							
							<div class="arrow"></div>
							
						</div>
						
						<div class="col-sm-4">
						
						<div class="destination"><?php echo $destination; ?></div>
						<div class="arrives">Arrives <?php echo $row["destinationArea"]; ?> at: <?php echo $row["arrival"]; ?></div>
						
						</div>
						
						<div class="col-sm-6 borderRight">
							<div class="operator"><?php echo $row["operator"]; ?></div>
							<div class="operatorSubscript">Operator</div>
						</div>
						
						<div class="col-sm-3 borderRight">
							<div class="class"><?php echo $date; ?></div>
							<div class="classSubscript">Date of journey</div>
						</div>
						
						<div class="col-sm-3">
							<div class="adults"><?php echo $noOfPassengers; ?></div>
							<div class="adultsSubscript">No. of passengers</div>
						</div>
					
					</div> <!-- boxLeft -->
				
				</div> <!-- col-sm-7 Departure -->
				
				</div>
				
				<div class="col-sm-5"> <!-- fare container -->
				
				<div class="col-sm-12">
				
					<div class="boxRightBus">
					
					<div class="col-sm-12 fareSummary">Fare Summary</div>
						
					<div class="col-sm-8">
						<div class="heading"><?php echo $noOfPassengers; ?> Passengers</div>
						<div class="heading">Convenience Fee</div>	
					</div>
					
					<div class="col-sm-4">
						<div class="price"><span class="sansSerif">₹ </span><?php echo $noOfPassengers*$row["fare"]; ?></div>
						<div class="price"><span class="sansSerif">₹ </span>250</div>
					</div>	
					
					<div class="col-sm-12">
							
							<div class="calcBar"></div>
							
					</div>
					
					<div class="col-sm-8">
						<div class="headingTotal">Total Fare</div>
					</div>
					
					<div class="col-sm-4">
						<div class="priceTotal"><span class="sansSerif">₹ </span><?php echo ($noOfPassengers*$row["fare"])+250; ?></div>
					</div>
					
					<form action="passengers.php" method="POST">
					
						<div class="bookingButton text-center">
							<input type="submit" class="confirmButton" value="Confirm Booking">
						</div>
						
						<?php $totalFare = ($noOfPassengers*$row["fare"])+250; ?>
						
						<input type="hidden" name="fareHidden" value="<?php echo $totalFare; ?>">
						<input type="hidden" name="typeHidden" value="<?php echo $type; ?>">
						<input type="hidden" name="originHidden" value="<?php echo $origin; ?>">
						<input type="hidden" name="destinationHidden" value="<?php echo $destination; ?>">
						<input type="hidden" name="departHidden" value="<?php echo $depart; ?>">
						<input type="hidden" name="returnHidden" value="<?php echo $return; ?>">
						<input type="hidden" name="noOfPassengersHidden" value="<?php echo $noOfPassengers; ?>">
						<input type="hidden" name="flightNoOutboundHidden" value="<?php echo $row["flight_no"]; ?>">
						<input type="hidden" name="modeHidden" value="<?php echo "bus"; ?>">
						<input type="hidden" name="busIDHidden" value="<?php echo $busID; ?>">
						<input type="hidden" name="dateHidden" value="<?php echo $date; ?>">
						<input type="hidden" name="classHidden" value="null">
						<input type="hidden" name="adultsHidden" value="0">
						<input type="hidden" name="childrenHidden" value="0">
					
					</form>
					
				</div>
				
			</div> <!-- col-sm-5 Fare -->
			
				</div> <!-- fare container -->
				
			</div> <!-- bus -->
			
			<?php elseif($mode=="train"): ?>
			
			<div class="col-sm-12 bookingTrain">
			
			<?php
				
				$trainID = $_POST["trainIdPass"];
				$date=$_POST["dateHidden"];
				$day=$_POST["dayHidden"];
				$origin=$_POST["originHidden"];
				$destination=$_POST["destinationHidden"];
				$class=$_POST["classHidden"];
				$noOfPassengers= $_POST["passengersHidden"];
				$priceClass = trim('price'.$class);
				
				$trainFinderSQL = "SELECT * FROM `trains` WHERE trainNo='$trainID'";
				$trainFinderQuery = $conn->query($trainFinderSQL);
				$row = $trainFinderQuery->fetch_assoc();
				//$outboundFlightFare = $outboundFlightQuery->fetch_array(MYSQLI_NUM);
				
			?>
				
				<div class="col-sm-7"> <!-- departure container -->
				
				<div class="col-sm-12">
				
					<div class="boxLeftBus">
					
						<div class="col-sm-12 mode">Departure</div>
						
						<div class="col-sm-4">
						
						<div class="origin"><?php echo $origin; ?></div>
						<div class="departs">Departs at: <?php echo $row["originTime"]; ?></div>
						
						</div>
						
						<div class="col-sm-4">
							
							<div class="arrow"></div>
							
						</div>
						
						<div class="col-sm-4">
						
						<div class="destination"><?php echo $destination; ?></div>
						<div class="arrives">Arrives at: <?php echo $row["destinationTime"]; ?></div>
						
						</div>
						
						<div class="col-sm-3 borderRight">
							<div class="class"><?php echo $date; ?></div>
							<div class="classSubscript">Date of journey</div>
						</div>
						
						<div class="col-sm-5 borderRight">
							<div class="operator"><?php echo $row["trainName"]; ?></div>
							<div class="operatorSubscript">Name of the train</div>
						</div>
						
						<div class="col-sm-2 borderRight">
							<div class="operator"><?php echo $class; ?></div>
							<div class="operatorSubscript">Class</div>
						</div>
						
						<div class="col-sm-2">
							<div class="adults"><?php echo $noOfPassengers; ?></div>
							<div class="adultsSubscript">Passengers</div>
						</div>
					
					</div> <!-- boxLeft -->
				
				</div> <!-- col-sm-7 Departure -->
				
				</div>
				
				<div class="col-sm-5"> <!-- fare container -->
				
				<div class="col-sm-12">
				
					<div class="boxRightBus">
					
					<div class="col-sm-12 fareSummary">Fare Summary</div>
						
					<div class="col-sm-8">
						<div class="heading"><?php echo $noOfPassengers; ?> Passengers</div>
						<div class="heading">Convenience Fee</div>	
					</div>
					
					<div class="col-sm-4">
						<div class="price"><span class="sansSerif">₹ </span><?php echo $noOfPassengers*$row[$priceClass]; ?></div>
						<div class="price"><span class="sansSerif">₹ </span>250</div>
					</div>	
					
					<div class="col-sm-12">
							
							<div class="calcBar"></div>
							
					</div>
					
					<div class="col-sm-8">
						<div class="headingTotal">Total Fare</div>
					</div>
					
					<div class="col-sm-4">
						<div class="priceTotal"><span class="sansSerif">₹ </span><?php echo ($noOfPassengers*$row[$priceClass])+250; ?></div>
					</div>
					
					<form action="passengers.php" method="POST">
					
						<div class="bookingButton text-center">
							<input type="submit" class="confirmButton" value="Confirm Booking">
						</div>
						
						<?php $totalFare = ($noOfPassengers*$row[$priceClass])+250; ?>
						
						<input type="hidden" name="fareHidden" value="<?php echo $totalFare; ?>">
						<input type="hidden" name="dateHidden" value="<?php echo $date; ?>">
						<input type="hidden" name="dayHidden" value="<?php echo $day; ?>">
						<input type="hidden" name="originHidden" value="<?php echo $origin; ?>">
						<input type="hidden" name="destinationHidden" value="<?php echo $destination; ?>">
						<input type="hidden" name="classHidden" value="<?php echo $class; ?>">
						<input type="hidden" name="noOfPassengersHidden" value="<?php echo $noOfPassengers; ?>">
						<input type="hidden" name="modeHidden" value="<?php echo "train"; ?>">
						<input type="hidden" name="trainIDHidden" value="<?php echo $trainID; ?>">
					
					</form>
					
				</div>
				
			</div> <!-- col-sm-5 Fare -->
			
				</div> <!-- fare container -->
				
			</div> <!-- train -->
			
			<?php endif; ?>
			
		</div> <!--bookingWrapper -->
		
	<div class="spacerLarge">.</div> <!-- just a dummy class for creating some space -->
    
    <!--- /rooms ---->
		
<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
				
	</body>
	
	<!-- BODY TAG ENDS -->
	
</html>